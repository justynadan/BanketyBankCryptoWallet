package com.example.BanketyBankCryptoWallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanketyBankCryptoWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
