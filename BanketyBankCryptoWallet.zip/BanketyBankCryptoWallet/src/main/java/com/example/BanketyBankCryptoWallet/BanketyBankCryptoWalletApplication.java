package com.example.BanketyBankCryptoWallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanketyBankCryptoWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanketyBankCryptoWalletApplication.class, args);
	}

}
